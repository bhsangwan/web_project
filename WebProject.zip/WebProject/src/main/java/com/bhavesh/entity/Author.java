package com.bhavesh.entity;

import java.util.Objects;

public class Author {
	private int author_id;
	private String name;
	private String email;
	private String address;
	
	public Author() {}

	public Author(int author_id, String name, String email, String address) {
		super();
		this.author_id = author_id;
		this.name = name;
		this.email = email;
		this.address = address;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, author_id, email, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Author other = (Author) obj;
		return Objects.equals(address, other.address) && author_id == other.author_id
				&& Objects.equals(email, other.email) && Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "Author [author_id=" + author_id + ", name=" + name + ", email=" + email + ", address=" + address + "]";
	}
	
	

}
