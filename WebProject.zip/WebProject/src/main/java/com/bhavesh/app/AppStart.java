package com.bhavesh.app;

import com.bhavesh.entity.Author;
import com.bhavesh.entity.Book;
import com.bhavesh.utils.BookUtils;
import com.bhavesh.utils.BookUtilsImpl;

public class AppStart {

	public static void main(String[] args) {	
		/*
		 * Midnight Children
		 * Author - Bhavesh
		 * ISBN - abdc-1234-bcds;
		 */
		
		/*
		 * Author author = new Author(); author.setAuthor_id(3);
		 * 
		 * Book book = new Book(0, "Midnight Children", "abdc-1234-bcds", author);
		 * 
		 * BookUtils util = new BookUtilsImpl(); if(util.addNewBook(book)) {
		 * System.out.println("Book added successfully..!"); }else {
		 * System.out.println("Operation Failed..!"); }
		 */
		
		BookUtils util = new BookUtilsImpl();
		Book book = util.getBookDetails(1);
		
		System.out.println("Book Title - "+book.getTitle());
		System.out.println("ISBN - "+book.getIsbn());

	}

}
