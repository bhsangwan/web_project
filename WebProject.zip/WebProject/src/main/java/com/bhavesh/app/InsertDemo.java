package com.bhavesh.app;

import java.sql.*;

public class InsertDemo {

	public static void main(String[] args) throws SQLException{
		Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=sample_db;integratedSecurity=true;");
		String query = "INSERT INTO AUTHOR (name, email, address) VALUES (?, ?, ?)";
		
		PreparedStatement pst = conn.prepareStatement(query);
		pst.setString(1, "Hariom");
		pst.setString(2, "hariom@gmail.com");
		pst.setString(3, "Gurugram");
		
		int rowCount = pst.executeUpdate();
		
		if(rowCount > 0) {
			System.out.println("Data inserted successfully..!");
		}else {
			System.out.println("Something went wrong. Try again..!");
		}
		
		conn.close();
	}

}
