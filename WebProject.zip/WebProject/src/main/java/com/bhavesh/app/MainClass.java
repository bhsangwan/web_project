package com.bhavesh.app;

import java.sql.*;

public class MainClass {

	public static void main(String[] args) {
		String url = "jdbc:sqlserver://localhost:1433;databaseName=sample_db;integratedSecurity=true;";
		String username = "", password = "";
		try {
			//STEP 1: Create the Connection Object
			Connection conn = DriverManager.getConnection(url);
			//STEP 2
			Statement stmt = conn.createStatement();
			
			//STEP 3
			String query = "SELECT * FROM AUTHOR";
			ResultSet rs = stmt.executeQuery(query);
			
			//STEP 4
			while(rs.next()) {
				System.out.println("Author ID: "+rs.getInt(1));
				System.out.println("Name : "+rs.getString(2));
				System.out.println("Email : "+rs.getString(3));
				System.out.println(("Address : "+rs.getString(4)));
			}
			
			//STEP 5 - close connection
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
