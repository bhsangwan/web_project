package com.bhavesh.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bhavesh.entity.*;

public class BookUtilsImpl implements BookUtils{

	String url = "jdbc:sqlserver://localhost:1433;databaseName=sample_db;integratedSecurity=true;";
	String username = "";
	String password = "";
	
	@Override
	public boolean addNewBook(Book book)  {
		boolean bookAdded = false;
		try {
			Connection conn = DriverManager.getConnection(url);
			String query = "INSERT INTO book (title, isbn, author_id) VALUES (?, ?, ?)";
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, book.getTitle());
			pst.setString(2, book.getIsbn());
			pst.setInt(3, book.getAuthor().getAuthor_id());
			
			int rowCount = pst.executeUpdate();
			
			conn.close();
			if(rowCount > 0) {
				bookAdded = true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return bookAdded;
	}

	@Override
	public void deleteBook(int book_id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Book getBookDetails(int book_id) {
		Book book = null;
		try {
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM BOOK WHERE book_id=?";
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setInt(1, book_id);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				book = new Book();
				book.setBook_id(rs.getInt(1));
				book.setTitle(rs.getString(2));
				book.setIsbn(rs.getString(3));
				
				Author author = new Author();
				author.setAuthor_id(rs.getInt(4));
				
				book.setAuthor(author);
			}
			
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return book;
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> books = new ArrayList<Book>();
		Book book = null;
		try {
			Connection conn = DriverManager.getConnection(url);
			String query = "SELECT * FROM BOOK";
			PreparedStatement pst = conn.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				book = new Book();
				book.setBook_id(rs.getInt(1));
				book.setTitle(rs.getString(2));
				book.setIsbn(rs.getString(3));
				
				Author author = new Author();
				author.setAuthor_id(rs.getInt(4));
				
				book.setAuthor(author);
				books.add(book);
			}
			
			conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return books;
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
