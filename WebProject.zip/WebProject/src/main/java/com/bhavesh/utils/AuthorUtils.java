package com.bhavesh.utils;

import java.util.List;

import com.bhavesh.entity.Author;

public interface AuthorUtils {
	
	public boolean addAuthor(Author author);
	
	public boolean deleteAuthor(int author_id);
	
	public Author getAuthor(int author_id);
	
	public List<Author> getAuthorList();

}
