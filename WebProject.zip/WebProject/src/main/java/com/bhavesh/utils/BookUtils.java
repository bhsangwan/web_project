package com.bhavesh.utils;
import com.bhavesh.entity.*;

import java.sql.SQLException;
import java.util.*;
public interface BookUtils {

	public boolean addNewBook(Book book);
	public void deleteBook(int book_id);
	public Book getBookDetails(int book_id);
	public List<Book> getAllBooks();
	public Book updateBook(Book book);
	
}
